def test():
    return 'python'
