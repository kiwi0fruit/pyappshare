def test():
    return 'python'

def cli():
    print('Hello!')
    input("Press Enter to exit.")
