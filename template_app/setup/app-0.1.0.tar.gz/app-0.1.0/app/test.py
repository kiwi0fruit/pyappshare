def test()
    return 'python'
