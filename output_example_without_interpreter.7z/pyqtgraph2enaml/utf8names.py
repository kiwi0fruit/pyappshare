# -*- coding: utf-8 -*-

class UTF8Names:
    button = "Test Enaml-PySide bug"
    title = "PyQtGraph to Enaml integration"
    text = "Here should be alpha betta gamma: αβγ"
